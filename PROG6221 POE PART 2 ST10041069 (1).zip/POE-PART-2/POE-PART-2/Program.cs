﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_PART_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Chatbot bitbuddy = new Chatbot();           
            bitbuddy.Greeting();
            bitbuddy.ImageDisplay();
            bitbuddy.GetUserName();
            bitbuddy.DisplayWelcome();
            bitbuddy.ConversationStarter();
            Console.WriteLine("\nThank you for using the Cybersecurity Awareness Bot!");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
